package object common {
  /** `???` can be used for marking methods that remain to be implemented.
   *  @throws  An `Error`
   */
  def ??? : Nothing = throw new Error("an implementation is missing")
  
  /** `xxx` used to throw an Error with an arbitrary error message 
   * @throws An `Error`
   */
  def xxx (msg: String) : Nothing = throw new Error(msg)
  
  type ??? = Nothing
  type *** = Any
  
}
