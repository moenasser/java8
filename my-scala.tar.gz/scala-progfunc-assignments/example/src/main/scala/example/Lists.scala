package example

import common._
import java.util.NoSuchElementException

object Lists {
  /**
   * This method computes the sum of all elements in the list xs. There are
   * multiple techniques that can be used for implementing this method, and
   * you will learn during the class.
   *
   * For this example assignment you can use the following methods in class
   * `List`:
   *
   *  - `xs.isEmpty: Boolean` returns `true` if the list `xs` is empty
   *  - `xs.head: Int` returns the head element of the list `xs`. If the list
   *    is empty an exception is thrown
   *  - `xs.tail: List[Int]` returns the tail of the list `xs`, i.e. the the
   *    list `xs` without its `head` element
   *
   *  ''Hint:'' instead of writing a `for` or `while` loop, think of a recursive
   *  solution.
   *
   * @param xs A list of natural numbers
   * @return The sum of all elements in `xs`
   */
  def sum(xs: List[Int]): Int = if (!xs.isEmpty) xs.head + sum( xs.tail) else 0

  /**
   * This method returns the largest element in a list of integers. If the
   * list `xs` is empty it throws a `java.util.NoSuchElementException`.
   *
   * You can use the same methods of the class `List` as mentioned above.
   *
   * ''Hint:'' Again, think of a recursive solution instead of using looping
   * constructs. You might need to define an auxiliary method.
   *
   * @param xs A list of natural numbers
   * @return The largest element in `xs`
   * @throws java.util.NoSuchElementException if `xs` is an empty list
   */
  def max(xs: List[Int]): Int = 
    if(xs.isEmpty) throw new NoSuchElementException 
  	else maxHelp( xs.tail, xs.head)
  
  /**
   * Helper function to max. Does actual recursion assuming 
   * a starting maximum and a tail of a list.
   * Holds on to the current maximum seen as it recurses over
   * the list - returns current maximum 
   * 
   * @param xs Remaining tail of list of natural numbers
   * @param m Current maximum seen
   * @return The largest element
   */
  def maxHelp(xs: List[Int], m: Int): Int =
    if( xs.isEmpty)
      m
    else
      if(m > xs.head) maxHelp(xs.tail, m)
      else maxHelp(xs.tail, xs.head)
}
