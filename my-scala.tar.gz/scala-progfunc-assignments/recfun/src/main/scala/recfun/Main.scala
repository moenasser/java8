package recfun
import common._

object Main {
  def main(args: Array[String]) {
    println("Pascal's Triangle")
    for (row <- 0 to 10) {
      for (col <- 0 to row)
        print(pascal(col, row) + " ")
      println()
    }
    
    println( balance("".toList) )
    println( balance("(if (zero? x) max (/ 1 x))".toList) )
    println( balance("I told him (that it’s not (yet) done). (But he wasn’t listening)".toList) )
    println( balance(":-)".toList) )
    println( balance("())(".toList) )
    
    println( countChange(5, List(1)) )
    println( countChange(5, List(5)) )
    println( countChange(5, List(5,1)) )
    println( countChange(5, List(1,5)) )
    println( countChange(5, List(1,2)) )

    println( countChange(21, List(1)) )
    println( countChange(21, List(5)) )
    println( countChange(21, List(5,1)) )
    println( countChange(21, List(1,5)) )
    println( countChange(21, List(1,2)) )

    println( countChange(300,List(5,10,20,50,100,200,500)) )  
  }

  /**
   * Exercise 1
   */
  def pascal(c: Int, r: Int): Int = 
    if (c==0 || c==r) 1
    else 
        pascal(c-1, r-1) + pascal(c, r-1)

        
  /**
   * Exercise 2
   */
  def balance(chars: List[Char]): Boolean = 
    if (chars.isEmpty) true
    else
      balanceHelper( 0 , chars) == 0
      
  def balanceHelper(c: Int, chars: List[Char]): Int=
    if (chars.isEmpty) c
    else
      // The case of an unbalanced open-parentheses
      if (chars.head == ')' && c < 1 )
        -1
      else
    	if( chars.head == '(' )
    		balanceHelper( c+1, chars.tail)
    	else
    	  if (chars.head == ')')
    		balanceHelper( c-1 , chars.tail)
    		else
    		  balanceHelper(c, chars.tail)
    

  /**
   * Exercise 3
   */
  def countChange(money: Int, coins: List[Int]): Int =
    if (coins.isEmpty) 0
    else
      if (coins.head == money) 1 + countChange(money, coins.tail)
      else
        // First coin fits within the amount left, test against possibilities of money less the current coin
        if (coins.head < money)
          countChange(money - coins.head, coins) +
          //countChange(money - coins.head, coins.tail) + // this gives permutation not combination
          countChange(money, coins.tail)
        else
          // The coin is too large, prune it for the rest of the tree
          countChange(money , coins.tail)
          
  
  
}
