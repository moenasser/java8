package week2

object session1 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(76); 
  println("Welcome to the Scala worksheet");$skip(73); 

  def gcd(a: Int, b: Int): Int =
    if (b == 0) a else gcd( b, a % b );System.out.println("""gcd: (a: Int, b: Int)Int""");$skip(20); val res$0 = 
    
  gcd( 14, 21);System.out.println("""res0: Int = """ + $show(res$0));$skip(8); val res$1 = 
  14%21;System.out.println("""res1: Int(14) = """ + $show(res$1));$skip(79); 
  
  
  def factorial(n: Int): Int =
    if (n==0) 1 else n* factorial( n -1 );System.out.println("""factorial: (n: Int)Int""");$skip(22); val res$2 = 
    
  factorial( 4 );System.out.println("""res2: Int = """ + $show(res$2));$skip(17); val res$3 = 
  factorial( 5 );System.out.println("""res3: Int = """ + $show(res$3));$skip(17); val res$4 = 
  factorial( 6 );System.out.println("""res4: Int = """ + $show(res$4));$skip(17); val res$5 = 
  factorial( 7 );System.out.println("""res5: Int = """ + $show(res$5));$skip(17); val res$6 = 
  factorial( 8 );System.out.println("""res6: Int = """ + $show(res$6));$skip(17); val res$7 = 
  factorial( 9 );System.out.println("""res7: Int = """ + $show(res$7));$skip(18); val res$8 = 
  factorial( 10 );System.out.println("""res8: Int = """ + $show(res$8));$skip(18); val res$9 = 
  factorial( 11 );System.out.println("""res9: Int = """ + $show(res$9));$skip(18); val res$10 = 
  factorial( 12 );System.out.println("""res10: Int = """ + $show(res$10));$skip(385); 
  

  /*** Tail recursion is basically iterative speed. ***/
  
  def factorialTail(n: Int) = {
  	
  	// Here we could use the special annotation "@tailrec" as a hint - but unnessary
  	def factorial(curr: Int, runningTotal: Int): Int =
  		if (curr == n) n * runningTotal
  		else factorial(curr + 1, runningTotal * curr)
  	
  	if ( n == 1 || n == 0 ) 1
  	else factorial(1, 1)
  };System.out.println("""factorialTail: (n: Int)Int""");$skip(24); val res$11 = 
  
  factorialTail( 0 );System.out.println("""res11: Int = """ + $show(res$11));$skip(21); val res$12 = 
  factorialTail( 1 );System.out.println("""res12: Int = """ + $show(res$12));$skip(21); val res$13 = 
  factorialTail( 2 );System.out.println("""res13: Int = """ + $show(res$13));$skip(21); val res$14 = 
  factorialTail( 4 );System.out.println("""res14: Int = """ + $show(res$14));$skip(21); val res$15 = 
  factorialTail( 5 );System.out.println("""res15: Int = """ + $show(res$15));$skip(21); val res$16 = 
  factorialTail( 6 );System.out.println("""res16: Int = """ + $show(res$16));$skip(21); val res$17 = 
  factorialTail( 7 );System.out.println("""res17: Int = """ + $show(res$17));$skip(21); val res$18 = 
  factorialTail( 8 );System.out.println("""res18: Int = """ + $show(res$18));$skip(21); val res$19 = 
  factorialTail( 9 );System.out.println("""res19: Int = """ + $show(res$19))}
  
}