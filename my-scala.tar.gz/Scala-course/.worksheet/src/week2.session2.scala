package week2

object session2 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(69); 
  println(" Higher Order Functions");$skip(202); 
  
  // Basically Scala functions can get passed into them OTHER functions
  // and can RETURN other functions
  
  def sumSequence( a: Int, b: Int): Int =
   if (a > b) 0 else a + sumSequence(a +1, b);System.out.println("""sumSequence: (a: Int, b: Int)Int""");$skip(43); 
   
  
  def cube(x: Int): Int = x * x * x;System.out.println("""cube: (x: Int)Int""");$skip(110); 
  
  def sumSequenceCubes( a: Int, b: Int): Int =
    if (a > b) 0 else cube(a) + sumSequenceCubes( a + 1, b);System.out.println("""sumSequenceCubes: (a: Int, b: Int)Int""");$skip(24); val res$0 = 
  
  sumSequence( 3, 5);System.out.println("""res0: Int = """ + $show(res$0));$skip(12); val res$1 = 
  cube( 1 );System.out.println("""res1: Int = """ + $show(res$1));$skip(12); val res$2 = 
  cube( 2 );System.out.println("""res2: Int = """ + $show(res$2));$skip(12); val res$3 = 
  cube( 3 );System.out.println("""res3: Int = """ + $show(res$3));$skip(12); val res$4 = 
  cube( 4 );System.out.println("""res4: Int = """ + $show(res$4));$skip(27); val res$5 = 
  sumSequenceCubes( 1, 4 );System.out.println("""res5: Int = """ + $show(res$5));$skip(18); val res$6 = 
  1 + 8 + 27 + 64;System.out.println("""res6: Int = """ + $show(res$6));$skip(399); 


	 //// It seems we want a function that TAKES IN an algorithm and simply summates
	 //// over the sequence while calling the passed in algorithm to work on the numbers
	 //// along the way ....
	 //// we need a higher order function ...
	 
	 /**
	  * Notice the first element is a function that
	  */
	 def sum( f: Int => Int, a: Int, b: Int): Int =
	   if (a>b) 0
	   else f(a) + sum( f, a+1, b);System.out.println("""sum: (f: Int => Int, a: Int, b: Int)Int""")}
	   
}